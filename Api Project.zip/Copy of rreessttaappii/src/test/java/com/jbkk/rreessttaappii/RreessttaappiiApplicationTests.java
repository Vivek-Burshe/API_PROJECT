package com.jbkk.rreessttaappii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RreessttaappiiApplicationTests {

	@Test
	void contextLoads() {
	}

}
