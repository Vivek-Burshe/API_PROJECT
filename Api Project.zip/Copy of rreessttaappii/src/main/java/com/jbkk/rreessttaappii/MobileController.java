package com.jbkk.rreessttaappii;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class MobileController {
	
@Autowired
SessionFactory factory;

@RequestMapping("getData")
public TreeSet<Mobile> getData(){
	//List<Mobile> list =	factory.openSession().createCriteria(Mobile.class).list();
	//List<Mobile> list =	factory.openSession().addAnnotatedClass(Mobile.class).createQuery("from Mobile").list();
//	System.out.println(list);
	Session session = factory.openSession();
	Query query = session.createQuery("from com.jbkk.rreessttaappii.Mobile");
	List<Mobile> list =query.list();

TreeSet<Mobile> treeset=new TreeSet(new SortOnPrice());
		
		for (Mobile mobile : list) 
		{
			int price=mobile.price;
			
			if(price>=15 && price<=30)
				treeset.add(mobile);
		}
		
	return treeset;
}
	
	
	
}
