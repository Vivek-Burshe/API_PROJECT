package com.jbkk.rreessttaappii;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class MycController {

	//localhost:8080/apicall

	@RequestMapping("apicall")
	public String apicall(){

		return "apicall";

	}

	@RequestMapping("test")
	public ModelAndView test(){
		
		ArrayList<String> arrayList= new ArrayList<String>();
	
		arrayList.add("jbk");
		arrayList.add("javabykiran");
		arrayList.add("the kiran Academy");
		


		ModelAndView modelAndView = new ModelAndView("test", "data", arrayList) ;

		return  modelAndView;
	}

}
